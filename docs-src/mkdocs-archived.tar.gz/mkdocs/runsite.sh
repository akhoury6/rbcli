#!/usr/bin/env bash

mkdocs serve
